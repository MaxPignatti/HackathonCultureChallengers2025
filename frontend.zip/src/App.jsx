import AvatarCreator from './AvatarCreator';
import './style.css';

export default function App() {
  return <AvatarCreator />;
}
